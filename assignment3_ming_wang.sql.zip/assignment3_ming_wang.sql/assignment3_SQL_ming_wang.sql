/** 
 ** Name: Ming Wang
 ** Assignment: 3
 ** Date: Oct 12nd, 2023
 **/
 
--Q1:
-- Drop the table if it already exists
DROP TABLE IF EXISTS ArtExhibits;

-- Create the new table
CREATE TABLE ArtExhibits (
    exhibit_code      CHAR(8) NOT NULL,
    artwork_name      VARCHAR(50),
    visitor_count     INTEGER,
    exhibit_area_m2   NUMERIC(8,2),
CONSTRAINT ExhibitPK 
	PRIMARY KEY(exhibit_code)
);

--Q2:
-- Insert data into ArtExhibits table
INSERT INTO ArtExhibits (exhibit_code, artwork_name, visitor_count, exhibit_area_m2)
VALUES ('EXB12345', 'Starry Night', 2500, 20.5);

INSERT INTO ArtExhibits (exhibit_code, artwork_name, visitor_count, exhibit_area_m2)
VALUES ('EXB12346', 'The Persistence of Memory', 3100, 15.3);

INSERT INTO ArtExhibits (exhibit_code, artwork_name, visitor_count, exhibit_area_m2)
VALUES ('EXB12347', 'Mona Lisa', 5000, 25.7);

-- In this insert, the 'artwork_name' and 'visitor_count' columns are not specified.
-- The database will insert default values (NULL if not specified during table creation) for the missing columns.
-- Comment: The 'artwork_name' and 'visitor_count' columns are missing in this INSERT statement.
INSERT INTO ArtExhibits (exhibit_code, exhibit_area_m2)
VALUES ('EXB12348', 18.4);

-- Select the newly inserted data
SELECT *
FROM ArtExhibits 
WHERE exhibit_code BETWEEN 'EXB12345' AND 'EXB12348';

--Q3:
/*
 * Update the 'Starry Night' exhibit data in the ArtExhibits table.
 * This will modify the artwork name, visitor count, 
 * and exhibit area for the row with exhibit_code 'EXB12345'.
 */
UPDATE ArtExhibits 
SET artwork_name = 'Starry Night Revised', visitor_count = 2600, exhibit_area_m2 = 21.0
WHERE exhibit_code = 'EXB12345';

-- Select the updated data for verification
SELECT *
FROM ArtExhibits 
WHERE exhibit_code = 'EXB12345';

/*
 *Delete the 'Mona Lisa' exhibit from the ArtExhibits table based on its exhibit_code 'EXB12347'.
 *Comment: The row with the 'Mona Lisa' 
 *exhibit (exhibit_code 'EXB12347') will be removed from the table.
 */
DELETE FROM ArtExhibits 
WHERE exhibit_code = 'EXB12347';

-- Select data to ensure the 'Mona Lisa' exhibit has been deleted
SELECT *
FROM ArtExhibits 
WHERE exhibit_code = 'EXB12347';

--Q5:
-- Drop the table if it already exists
DROP TABLE IF EXISTS Route;
-- Creating the Route table
CREATE TABLE Route (
    RoutingID         CHAR(6)      NOT NULL,
    LengthOfRoute     NUMERIC(4, 2) CHECK (LengthOfRoute IS NULL 
										   OR (LengthOfRoute > 0 
											   AND LengthOfRoute < 20)),
    DepartureCityName VARCHAR(85)  NOT NULL,
    ArrivalCityName   VARCHAR(85)  NOT NULL,
CONSTRAINT RoutePK
	PRIMARY KEY (RoutingID)
);

-- Drop the table if it already exists
DROP TABLE IF EXISTS Plane;
-- Creating the Plane table
CREATE TABLE Plane (
    PlaneSerialNumber NUMERIC(10, 0) NOT NULL,
    PlaneName         VARCHAR(100)   NOT NULL,
    FuelCapacity      NUMERIC(9, 2)  CHECK (FuelCapacity IS NULL 
											OR (FuelCapacity > 0 
												AND FuelCapacity <= 300000)),
CONSTRAINT PlanePK
	PRIMARY KEY (PlaneSerialNumber)
);

-- Drop the table if it already exists
DROP TABLE IF EXISTS Plane_Route_Association;
-- Creating the Plane_Route_Association table
CREATE TABLE Plane_Route_Association (
    PlaneSerialNumber NUMERIC(10, 0) NOT NULL,
    RoutingID         CHAR(6)        NOT NULL,
    DepartureDate     DATE           NOT NULL,
    ArrivalDate       DATE           NOT NULL CHECK (ArrivalDate >= DepartureDate),
CONSTRAINT PK_PlaneRoute 
	PRIMARY KEY (PlaneSerialNumber, RoutingID),
CONSTRAINT FK_Plane
	FOREIGN KEY (PlaneSerialNumber)
	REFERENCES Plane(PlaneSerialNumber),
CONSTRAINT FK_Route
	FOREIGN KEY (RoutingID)
	REFERENCES Route(RoutingID)
);

-- The valid inserts for demonstration
INSERT INTO Route (RoutingID, DepartureCityName, ArrivalCityName) 
VALUES ('R12345', 'Winnipeg', 'Toronto');
INSERT INTO Plane (PlaneSerialNumber, PlaneName) 
VALUES (1234567890, 'AirCanada A123');
INSERT INTO Plane_Route_Association (PlaneSerialNumber, RoutingID, DepartureDate, ArrivalDate) 
VALUES (1234567890, 'R12345', '2023-10-11', '2023-10-12');


-- This INSERT will violate the NOT NULL constraint on DepartureCityName in the Route table
INSERT INTO Route (RoutingID, ArrivalCityName) 
VALUES ('R12346', 'Montreal');
-- This INSERT will violate the foreign key constraint as the RoutingID 'R99999' does not exist in the Route table
INSERT INTO Plane_Route_Association (PlaneSerialNumber, RoutingID, DepartureDate, ArrivalDate) 
VALUES (1234567890, 'R99999', '2023-10-15', '2023-10-16');
-- This INSERT will violate the check constraint for LengthOfRoute in the Route table as it's greater than 20
INSERT INTO Route (RoutingID, LengthOfRoute, DepartureCityName, ArrivalCityName) 
VALUES ('R12347', 25, 'Calgary', 'Vancouver');
-- This INSERT will violate the check constraint for FuelCapacity in the Plane table as it's greater than 300000
INSERT INTO Plane (PlaneSerialNumber, PlaneName, FuelCapacity) 
VALUES (9876543210, 'AirCanada A124', 350000);

